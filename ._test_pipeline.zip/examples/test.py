class Test:
    def __init__(self, x):
        self.x = x


t = Test(42)

t.x = 43

a = 42
print(a)
a


x = sc.range(0, 10).map(lambda x: x * x).collect()
x

del x

